# Changelog

All notable changes to Moreillon SEO will be documented in this file.

## [1.0.0] - 2025-10-15

### Design Update - DETAILED-Inspired UI 🎨

#### Changed
- **Header**: New dark professional design (`#2d3748`)
- **Tabs**: Dark theme with icons, better active state
- **Buttons**: Solid colors instead of gradients
- **Cards**: White background with borders, hover effects
- **Typography**: Improved hierarchy and spacing
- **Colors**: Professional palette (blues, greens, reds)

#### Added - New Features
- ✨ **Status Badges**: Color-coded indicators (green/yellow/red)
- ✨ **Character Count Badges**: For title and description
- ✨ **Export Functionality**: 
  - Export images without alt text
  - Export all images
- ✨ **Enhanced Stats Display**: Large numbers with labels
- ✨ **Heading Count Grid**: 6-column table view
- ✨ **Improved Quick Links**: Sitemap and robots.txt buttons
- ✨ **Icons**: Added to all tabs and labels

### Initial Release

#### Features
- 🖼️ Image Downloader with preview grid
- 🔍 SEO Analyzer with meta tags and heading analysis
- 📝 Typography Analyzer (fonts and sizes)
- 🎨 Color Analyzer and Color Picker

#### SEO Enhancements ✨
- **Quick Links**: Direct access to sitemap.xml and robots.txt
- **Structured Data Viewer**: View all schema markup types
  - JSON-LD with expandable formatted JSON
  - Microdata detection
  - Open Graph tags
  - Twitter Cards
- **Visual Heading Structure**: Revolutionary heading visualization
  - Indented by hierarchy level
  - Varying font sizes (H1 largest to H6 smallest)
  - Color-coded tags for each level
  - Shows all headings in document order
  - Easy over-optimization detection
- **Enhanced Meta Analysis**: Includes canonical URL, full Open Graph support

#### Technical Details
- Chrome Manifest V3
- EyeDropper API for color picking
- Modern, gradient-based UI
- Fully offline - no external servers
- Privacy-focused - no data collection

---

Format: [version] - YYYY-MM-DD

Types of changes:
- **Added** for new features
- **Changed** for changes in existing functionality
- **Deprecated** for soon-to-be removed features
- **Removed** for removed features
- **Fixed** for bug fixes
- **Security** for vulnerability fixes

