// Tab switching functionality with auto-analysis
const tabButtons = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

tabButtons.forEach(button => {
  button.addEventListener('click', () => {
    const tabName = button.dataset.tab;
    
    // Remove active class from all tabs and contents
    tabButtons.forEach(btn => btn.classList.remove('active'));
    tabContents.forEach(content => content.classList.remove('active'));
    
    // Add active class to clicked tab and corresponding content
    button.classList.add('active');
    document.getElementById(tabName).classList.add('active');
    
    // Auto-trigger analysis for the tab
    autoAnalyzeTab(tabName);
  });
});

// Auto-analyze function
function autoAnalyzeTab(tabName) {
  switch(tabName) {
    case 'images':
      if (images.length === 0) {
        analyzeImages();
      }
      break;
    case 'seo':
      analyzeSEO();
      break;
    case 'links':
      analyzeLinks();
      break;
    case 'typography':
      analyzeTypography();
      break;
    case 'colors':
      analyzeColors();
      break;
    case 'advanced':
      setupAdvancedLinks();
      break;
  }
}

// Auto-analyze images tab on load (since it's the default active tab)
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    analyzeImages();
  }, 100);
});

// ==================== ADVANCED TOOLS ====================
async function setupAdvancedLinks() {
  try {
    const tab = await getCurrentTab();
    const currentUrl = encodeURIComponent(tab.url);
    const url = new URL(tab.url);
    const domain = url.hostname;
    
    // Google PageSpeed Insights
    const pagespeedUrl = `https://pagespeed.web.dev/analysis?url=${currentUrl}`;
    document.getElementById('pagespeed-link').href = pagespeedUrl;
    
    // Google Rich Results Test
    const richResultsUrl = `https://search.google.com/test/rich-results?url=${currentUrl}`;
    document.getElementById('richresults-link').href = richResultsUrl;
    
    // WHOIS Lookup
    const whoisUrl = `https://www.whois.com/whois/${domain}`;
    document.getElementById('whois-link').href = whoisUrl;
    
  } catch (error) {
    console.error('Error setting up advanced links:', error);
  }
}

// Helper function to get current tab
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// Helper function to execute script in current tab
async function executeScript(func) {
  const tab = await getCurrentTab();
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: func
  });
  return result.result;
}

// ==================== IMAGE DOWNLOADER ====================
let images = [];
let selectedImages = new Set();

async function analyzeImages() {
  const imageGrid = document.getElementById('image-grid');
  const stats = document.getElementById('image-stats');
  
  imageGrid.innerHTML = '<div class="loading">Scanning images...</div>';
  stats.innerHTML = '';
  
  try {
    images = await executeScript(() => {
      const imgs = Array.from(document.querySelectorAll('img'));
      return imgs.map((img, index) => ({
        src: img.src,
        alt: img.alt || 'No alt text',
        width: img.naturalWidth,
        height: img.naturalHeight,
        index: index
      })).filter(img => img.src && img.width > 0 && img.height > 0);
    });
    
    if (images.length === 0) {
      imageGrid.innerHTML = '<div class="empty-state"><p>No images found on this page</p></div>';
      return;
    }
    
    stats.innerHTML = `<div style="padding: 8px 0; color: #2d3748; font-weight: 600; font-size: 14px;">Found ${images.length} images</div>`;
    renderImageGrid();
    
  } catch (error) {
    imageGrid.innerHTML = `<div class="empty-state"><p>Error: ${error.message}</p></div>`;
  }
}

function renderImageGrid() {
  const imageGrid = document.getElementById('image-grid');
  imageGrid.innerHTML = '';
  
  images.forEach((img, index) => {
    const item = document.createElement('div');
    item.className = 'image-item';
    if (selectedImages.has(index)) {
      item.classList.add('selected');
    }
    
    item.innerHTML = `
      <img src="${img.src}" alt="${img.alt}" loading="lazy">
      <div class="checkbox"></div>
      <div class="image-info">${img.width}×${img.height}</div>
    `;
    
    item.addEventListener('click', () => {
      if (selectedImages.has(index)) {
        selectedImages.delete(index);
        item.classList.remove('selected');
      } else {
        selectedImages.add(index);
        item.classList.add('selected');
      }
      updateStats();
    });
    
    imageGrid.appendChild(item);
  });
}

function updateStats() {
  const stats = document.getElementById('image-stats');
  const withoutAlt = images.filter(img => !img.alt || img.alt === 'No alt text').length;
  
  stats.innerHTML = `
    <div style="display: flex; gap: 15px; align-items: center; padding: 10px 0; color: #2d3748; font-size: 14px; font-weight: 600;">
      <span>📸 <strong>${images.length}</strong> Images</span>
      <span style="color: #cbd5e0;">|</span>
      <span>⚠️ <strong>${withoutAlt}</strong> Without Alt</span>
      <span style="color: #cbd5e0;">|</span>
      <span>✓ <strong style="color: #667eea;">${selectedImages.size}</strong> Selected</span>
    </div>
  `;
}

document.getElementById('select-all').addEventListener('click', () => {
  selectedImages = new Set(images.map((_, index) => index));
  renderImageGrid();
  updateStats();
});

document.getElementById('deselect-all').addEventListener('click', () => {
  selectedImages.clear();
  renderImageGrid();
  updateStats();
});

document.getElementById('download-selected').addEventListener('click', async () => {
  if (selectedImages.size === 0) {
    alert('Please select at least one image to download');
    return;
  }
  
  for (const index of selectedImages) {
    const img = images[index];
    try {
      await chrome.downloads.download({
        url: img.src,
        filename: `image_${index + 1}_${Date.now()}.jpg`,
        saveAs: false
      });
    } catch (error) {
      console.error('Download error:', error);
    }
  }
  
  alert(`Started downloading ${selectedImages.size} images`);
});

// Export all images
document.getElementById('export-complete').addEventListener('click', async () => {
  if (images.length === 0) {
    alert('No images to download');
    return;
  }
  
  // Get current tab info for folder name
  const tab = await getCurrentTab();
  const url = new URL(tab.url);
  const domain = url.hostname.replace(/^www\./, '');
  const timestamp = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const folderName = `moreillon-seo/${domain}_${timestamp}`;
  
  for (let i = 0; i < images.length; i++) {
    const img = images[i];
    try {
      // Extract file extension from URL or use .jpg as default
      let extension = '.jpg';
      const urlPath = img.src.split('?')[0]; // Remove query params
      const match = urlPath.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i);
      if (match) {
        extension = match[0].toLowerCase();
      }
      
      await chrome.downloads.download({
        url: img.src,
        filename: `${folderName}/image_${i + 1}${extension}`,
        saveAs: false
      });
    } catch (error) {
      console.error('Download error:', error);
    }
  }
  
  alert(`Started downloading ${images.length} images to folder: ${folderName}`);
});

// ==================== SEO ANALYZER ====================
async function analyzeSEO() {
  const quickLinks = document.getElementById('quick-links');
  const metaInfo = document.getElementById('meta-info');
  const contentAnalysis = document.getElementById('content-analysis');
  const headingStructure = document.getElementById('heading-structure');
  const headingInfo = document.getElementById('heading-info');
  const schemaInfo = document.getElementById('schema-info');
  
  quickLinks.innerHTML = '<div class="loading">Loading...</div>';
  metaInfo.innerHTML = '<div class="loading">Analyzing...</div>';
  contentAnalysis.innerHTML = '<div class="loading">Analyzing...</div>';
  headingStructure.innerHTML = '<div class="loading">Analyzing...</div>';
  headingInfo.innerHTML = '<div class="loading">Analyzing...</div>';
  schemaInfo.innerHTML = '<div class="loading">Analyzing...</div>';
  
  try {
    // Get current page URL
    const tab = await getCurrentTab();
    const currentUrl = new URL(tab.url);
    const sitemapUrl = `${currentUrl.protocol}//${currentUrl.hostname}/sitemap.xml`;
    const robotsUrl = `${currentUrl.protocol}//${currentUrl.hostname}/robots.txt`;
    
    // Render quick links
    quickLinks.innerHTML = `
      <div style="display: flex; gap: 10px;">
        <a href="${sitemapUrl}" target="_blank" class="quick-link-btn" style="flex: 1;">
          📄 Sitemap.xml
        </a>
        <a href="${robotsUrl}" target="_blank" class="quick-link-btn" style="flex: 1;">
          🤖 Robots.txt
        </a>
      </div>
    `;
    
    const seoData = await executeScript(() => {
      // Get meta information
      const metaTitle = document.querySelector('title')?.textContent || 'No title found';
      const metaDescription = document.querySelector('meta[name="description"]')?.content || 'No description found';
      const metaKeywords = document.querySelector('meta[name="keywords"]')?.content || 'No keywords found';
      const ogTitle = document.querySelector('meta[property="og:title"]')?.content || 'Not set';
      const ogDescription = document.querySelector('meta[property="og:description"]')?.content || 'Not set';
      const canonical = document.querySelector('link[rel="canonical"]')?.href || 'Not set';
      
      // Get ALL headings in document order
      const allHeadings = [];
      const headingElements = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
      headingElements.forEach((el) => {
        allHeadings.push({
          tag: el.tagName.toLowerCase(),
          text: el.textContent.trim().substring(0, 150)
        });
      });
      
      // Count headings
      const headings = {
        h1: document.querySelectorAll('h1').length,
        h2: document.querySelectorAll('h2').length,
        h3: document.querySelectorAll('h3').length,
        h4: document.querySelectorAll('h4').length,
        h5: document.querySelectorAll('h5').length,
        h6: document.querySelectorAll('h6').length
      };
      
      // Get actual heading texts (first few of each)
      const headingTexts = {};
      ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].forEach(tag => {
        const elements = Array.from(document.querySelectorAll(tag));
        headingTexts[tag] = elements.slice(0, 3).map(el => el.textContent.trim());
      });
      
      // Get structured data (JSON-LD, Microdata, etc.)
      const structuredData = [];
      
      // JSON-LD
      const jsonLdScripts = document.querySelectorAll('script[type="application/ld+json"]');
      jsonLdScripts.forEach((script, index) => {
        try {
          const data = JSON.parse(script.textContent);
          structuredData.push({
            type: 'JSON-LD',
            index: index,
            data: data,
            raw: script.textContent
          });
        } catch (e) {
          // Invalid JSON
        }
      });
      
      // Microdata
      const microdataElements = document.querySelectorAll('[itemscope]');
      if (microdataElements.length > 0) {
        structuredData.push({
          type: 'Microdata',
          count: microdataElements.length,
          types: Array.from(microdataElements).map(el => el.getAttribute('itemtype')).filter(t => t)
        });
      }
      
      // Open Graph
      const ogTags = document.querySelectorAll('meta[property^="og:"]');
      if (ogTags.length > 0) {
        const ogData = {};
        ogTags.forEach(tag => {
          const property = tag.getAttribute('property');
          ogData[property] = tag.getAttribute('content');
        });
        structuredData.push({
          type: 'Open Graph',
          data: ogData
        });
      }
      
      // Twitter Cards
      const twitterTags = document.querySelectorAll('meta[name^="twitter:"]');
      if (twitterTags.length > 0) {
        const twitterData = {};
        twitterTags.forEach(tag => {
          const name = tag.getAttribute('name');
          twitterData[name] = tag.getAttribute('content');
        });
        structuredData.push({
          type: 'Twitter Cards',
          data: twitterData
        });
      }
      
      // Count words in the main content
      // Remove scripts, styles, and other non-content elements
      const bodyClone = document.body.cloneNode(true);
      const elementsToRemove = bodyClone.querySelectorAll('script, style, noscript, iframe, nav, header, footer');
      elementsToRemove.forEach(el => el.remove());
      
      const bodyText = bodyClone.textContent || bodyClone.innerText || '';
      const words = bodyText.trim().split(/\s+/).filter(word => word.length > 0);
      const wordCount = words.length;
      
      // Count paragraphs
      const paragraphCount = document.querySelectorAll('p').length;
      
      // Count characters (excluding spaces)
      const charCount = bodyText.replace(/\s+/g, '').length;
      
      return {
        meta: { metaTitle, metaDescription, metaKeywords, ogTitle, ogDescription, canonical },
        headings,
        headingTexts,
        allHeadings,
        structuredData,
        content: { wordCount, paragraphCount, charCount }
      };
    });
    
    // Render meta information with character counts
    const titleLength = seoData.meta.metaTitle.length;
    const descLength = seoData.meta.metaDescription === 'No description found' ? 0 : seoData.meta.metaDescription.length;
    
    // Title: 50-60 chars ideal, warn if > 60
    let titleCharClass = 'good';
    if (titleLength > 60) titleCharClass = 'error';
    else if (titleLength < 30) titleCharClass = 'warning';
    
    // Description: 150-160 chars ideal, warn if > 160
    let descCharClass = 'good';
    if (descLength > 160) descCharClass = 'error';
    else if (descLength < 120) descCharClass = 'warning';
    else if (descLength === 0) descCharClass = 'error';
    
    const canonicalStatus = seoData.meta.canonical === 'Not set' 
      ? '<span class="status-badge error">Missing</span>' 
      : '<span class="status-badge good">Set</span>';
    
    metaInfo.innerHTML = `
      <div class="info-item" style="display: block;">
        <div class="info-label">
          📄 Title
          <span class="char-count ${titleCharClass}">${titleLength} characters of 60 recommended</span>
        </div>
        <div style="margin-top: 8px; color: #2d3748; font-size: 14px;">${seoData.meta.metaTitle}</div>
      </div>
      <div class="info-item" style="display: block;">
        <div class="info-label">
          📝 Meta Description
          <span class="char-count ${descCharClass}">${descLength} characters of 160 recommended</span>
        </div>
        <div style="margin-top: 8px; color: #2d3748; font-size: 14px;">${seoData.meta.metaDescription}</div>
      </div>
      <div class="info-item" style="display: block;">
        <div class="info-label">
          🔗 Canonical URL
          ${canonicalStatus}
        </div>
        <div style="margin-top: 8px; color: #2d3748; font-size: 13px; word-break: break-all;">${seoData.meta.canonical}</div>
      </div>
    `;
    
    // Render content analysis
    contentAnalysis.innerHTML = `
      <div class="content-stats-grid">
        <div class="content-stat-card">
          <div class="content-stat-icon">📝</div>
          <div class="content-stat-number">${seoData.content.wordCount.toLocaleString()}</div>
          <div class="content-stat-label">Words</div>
        </div>
        <div class="content-stat-card">
          <div class="content-stat-icon">📄</div>
          <div class="content-stat-number">${seoData.content.paragraphCount}</div>
          <div class="content-stat-label">Paragraphs</div>
        </div>
        <div class="content-stat-card">
          <div class="content-stat-icon">🔤</div>
          <div class="content-stat-number">${seoData.content.charCount.toLocaleString()}</div>
          <div class="content-stat-label">Characters</div>
        </div>
      </div>
    `;
    
    // Render heading structure (indented, with varying font sizes)
    if (seoData.allHeadings.length > 0) {
      let structureHTML = '';
      seoData.allHeadings.forEach((heading, index) => {
        structureHTML += `
          <div class="heading-structure-item ${heading.tag}">
            <span class="heading-tag-label ${heading.tag}">${heading.tag}</span>
            <span class="heading-text">${heading.text}</span>
          </div>
        `;
      });
      headingStructure.innerHTML = structureHTML;
    } else {
      headingStructure.innerHTML = '<div class="empty-state"><p>No headings found on this page</p></div>';
    }
    
    // Render heading summary table
    const totalHeadings = Object.values(seoData.headings).reduce((a, b) => a + b, 0);
    const h1Warning = seoData.headings.h1 > 1 ? '<span class="status-badge error">Multiple H1s!</span>' : 
                      seoData.headings.h1 === 0 ? '<span class="status-badge error">No H1 found!</span>' : 
                      '<span class="status-badge good">Good</span>';
    
    headingInfo.innerHTML = `
      <div class="info-item">
        <span class="info-label">📊 Total Headings</span>
        <span class="info-value">${totalHeadings}</span>
      </div>
      <div class="info-item">
        <span class="info-label">H1 Status</span>
        ${h1Warning}
      </div>
      <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; padding: 15px; background: #fff; border: 1px solid #e2e8f0; border-radius: 8px;">
        <div style="text-align: center;">
          <div style="font-size: 11px; color: #718096; text-transform: uppercase; margin-bottom: 5px;">H1</div>
          <div style="font-size: 24px; font-weight: 700; color: ${seoData.headings.h1 === 1 ? '#48bb78' : '#f56565'};">${seoData.headings.h1}</div>
        </div>
        <div style="text-align: center;">
          <div style="font-size: 11px; color: #718096; text-transform: uppercase; margin-bottom: 5px;">H2</div>
          <div style="font-size: 24px; font-weight: 700; color: #5a67d8;">${seoData.headings.h2}</div>
        </div>
        <div style="text-align: center;">
          <div style="font-size: 11px; color: #718096; text-transform: uppercase; margin-bottom: 5px;">H3</div>
          <div style="font-size: 24px; font-weight: 700; color: #5a67d8;">${seoData.headings.h3}</div>
        </div>
        <div style="text-align: center;">
          <div style="font-size: 11px; color: #718096; text-transform: uppercase; margin-bottom: 5px;">H4</div>
          <div style="font-size: 24px; font-weight: 700; color: #5a67d8;">${seoData.headings.h4}</div>
        </div>
        <div style="text-align: center;">
          <div style="font-size: 11px; color: #718096; text-transform: uppercase; margin-bottom: 5px;">H5</div>
          <div style="font-size: 24px; font-weight: 700; color: #5a67d8;">${seoData.headings.h5}</div>
        </div>
        <div style="text-align: center;">
          <div style="font-size: 11px; color: #718096; text-transform: uppercase; margin-bottom: 5px;">H6</div>
          <div style="font-size: 24px; font-weight: 700; color: #5a67d8;">${seoData.headings.h6}</div>
        </div>
      </div>
    `;
    
    // Render structured data with validation
    if (seoData.structuredData.length > 0) {
      let schemaHTML = `<div class="info-item"><span class="info-label">Found:</span><span class="info-value">${seoData.structuredData.length} schema type(s)</span></div>`;
      
      seoData.structuredData.forEach((schema, index) => {
        let content = '';
        
        if (schema.type === 'JSON-LD') {
          const schemaType = schema.data['@type'] || 'Unknown';
          const validation = validateSchema(schemaType, schema.data);
          
          content = `
            <div class="schema-type ${validation.status}" data-schema-id="schema-${index}">
              <div class="schema-header">
                <div class="schema-title">
                  <strong>${schema.type} - ${schemaType}</strong>
                  <span class="schema-health ${validation.status}">
                    ${validation.status === 'valid' ? '✓ Valid' : validation.status === 'warning' ? '⚠ Warnings' : '✗ Errors'}
                  </span>
                </div>
                <span class="schema-badge">▼ Click to view</span>
              </div>
              <div class="schema-content" style="display: none;">
                ${validation.issues.length > 0 ? `
                  <div class="schema-validation">
                    <h4>Validation Results:</h4>
                    ${validation.issues.map(issue => `
                      <div class="validation-item ${issue.level}">
                        <span class="validation-icon">${issue.level === 'error' ? '✗' : '⚠'}</span>
                        <span class="validation-message">${issue.message}</span>
                      </div>
                    `).join('')}
                  </div>
                ` : '<div class="schema-validation-success">✓ All checks passed!</div>'}
                <div class="schema-data-header">Schema Data:</div>
                <pre>${JSON.stringify(schema.data, null, 2)}</pre>
              </div>
            </div>
          `;
        } else if (schema.type === 'Microdata') {
          content = `
            <div class="schema-type valid">
              <div class="schema-type-header">
                <span>${schema.type}</span>
                <span class="schema-badge">${schema.count} items</span>
              </div>
              <div style="margin-top: 8px; font-size: 12px; color: #6c757d;">
                Types: ${schema.types.join(', ') || 'Not specified'}
              </div>
            </div>
          `;
        } else if (schema.type === 'Open Graph' || schema.type === 'Twitter Cards') {
          content = `
            <div class="schema-type valid" data-schema-id="schema-${index}">
              <div class="schema-header">
                <div class="schema-title">
                  <strong>${schema.type}</strong>
                  <span class="schema-health valid">✓ Found</span>
                </div>
                <span class="schema-badge">▼ Click to view</span>
              </div>
              <div class="schema-content" style="display: none;">
                <pre>${JSON.stringify(schema.data, null, 2)}</pre>
              </div>
            </div>
          `;
        }
        
        schemaHTML += content;
      });
      
      schemaInfo.innerHTML = schemaHTML;
      
      // Add click handlers for schema boxes
      document.querySelectorAll('.schema-type[data-schema-id]').forEach(schemaBox => {
        schemaBox.addEventListener('click', function() {
          const content = this.querySelector('.schema-content');
          const badge = this.querySelector('.schema-badge');
          
          if (content.style.display === 'none') {
            content.style.display = 'block';
            badge.textContent = '▲ Click to hide';
          } else {
            content.style.display = 'none';
            badge.textContent = '▼ Click to view';
          }
        });
      });
    } else {
      schemaInfo.innerHTML = '<div class="no-schema">No structured data found on this page</div>';
    }
    
  } catch (error) {
    metaInfo.innerHTML = `<div class="empty-state"><p>Error: ${error.message}</p></div>`;
    contentAnalysis.innerHTML = '';
    headingInfo.innerHTML = '';
    headingStructure.innerHTML = '';
    schemaInfo.innerHTML = '';
  }
}

// ==================== SCHEMA VALIDATOR ====================
function validateSchema(type, data) {
  const issues = [];
  
  // Check if data is valid
  if (!data || typeof data !== 'object') {
    issues.push({ level: 'error', message: 'Invalid schema data structure' });
    return { status: 'error', issues };
  }
  
  // Check for @context
  if (!data['@context']) {
    issues.push({ level: 'error', message: 'Missing @context property (required for JSON-LD)' });
  } else if (!data['@context'].includes('schema.org')) {
    issues.push({ level: 'warning', message: '@context should reference schema.org' });
  }
  
  // Check for @type
  if (!data['@type']) {
    issues.push({ level: 'error', message: 'Missing @type property (required)' });
  }
  
  // Type-specific validation
  switch (type) {
    case 'Organization':
      if (!data.name) issues.push({ level: 'error', message: 'Missing required "name" property' });
      if (!data.url) issues.push({ level: 'warning', message: 'Missing recommended "url" property' });
      if (!data.logo) issues.push({ level: 'warning', message: 'Missing recommended "logo" property' });
      break;
      
    case 'Person':
      if (!data.name) issues.push({ level: 'error', message: 'Missing required "name" property' });
      break;
      
    case 'Article':
    case 'NewsArticle':
    case 'BlogPosting':
      if (!data.headline) issues.push({ level: 'error', message: 'Missing required "headline" property' });
      if (!data.image) issues.push({ level: 'warning', message: 'Missing recommended "image" property' });
      if (!data.datePublished) issues.push({ level: 'warning', message: 'Missing recommended "datePublished" property' });
      if (!data.author) issues.push({ level: 'warning', message: 'Missing recommended "author" property' });
      break;
      
    case 'Product':
      if (!data.name) issues.push({ level: 'error', message: 'Missing required "name" property' });
      if (!data.image) issues.push({ level: 'warning', message: 'Missing recommended "image" property' });
      if (!data.description) issues.push({ level: 'warning', message: 'Missing recommended "description" property' });
      if (!data.offers && !data.offers?.price) {
        issues.push({ level: 'warning', message: 'Missing recommended "offers" with price' });
      }
      break;
      
    case 'Recipe':
      if (!data.name) issues.push({ level: 'error', message: 'Missing required "name" property' });
      if (!data.image) issues.push({ level: 'error', message: 'Missing required "image" property' });
      if (!data.recipeIngredient) issues.push({ level: 'error', message: 'Missing required "recipeIngredient" property' });
      if (!data.recipeInstructions) issues.push({ level: 'error', message: 'Missing required "recipeInstructions" property' });
      break;
      
    case 'Event':
      if (!data.name) issues.push({ level: 'error', message: 'Missing required "name" property' });
      if (!data.startDate) issues.push({ level: 'error', message: 'Missing required "startDate" property' });
      if (!data.location) issues.push({ level: 'error', message: 'Missing required "location" property' });
      break;
      
    case 'LocalBusiness':
      if (!data.name) issues.push({ level: 'error', message: 'Missing required "name" property' });
      if (!data.address) issues.push({ level: 'warning', message: 'Missing recommended "address" property' });
      if (!data.telephone) issues.push({ level: 'warning', message: 'Missing recommended "telephone" property' });
      break;
      
    case 'FAQPage':
      if (!data.mainEntity || !Array.isArray(data.mainEntity)) {
        issues.push({ level: 'error', message: 'Missing required "mainEntity" array with questions' });
      }
      break;
      
    case 'BreadcrumbList':
      if (!data.itemListElement || !Array.isArray(data.itemListElement)) {
        issues.push({ level: 'error', message: 'Missing required "itemListElement" array' });
      }
      break;
      
    case 'VideoObject':
      if (!data.name) issues.push({ level: 'error', message: 'Missing required "name" property' });
      if (!data.description) issues.push({ level: 'error', message: 'Missing required "description" property' });
      if (!data.thumbnailUrl) issues.push({ level: 'error', message: 'Missing required "thumbnailUrl" property' });
      if (!data.uploadDate) issues.push({ level: 'error', message: 'Missing required "uploadDate" property' });
      break;
      
    case 'WebSite':
      if (!data.name) issues.push({ level: 'warning', message: 'Missing recommended "name" property' });
      if (!data.url) issues.push({ level: 'warning', message: 'Missing recommended "url" property' });
      break;
  }
  
  // Determine overall status
  let status = 'valid';
  if (issues.some(i => i.level === 'error')) {
    status = 'error';
  } else if (issues.some(i => i.level === 'warning')) {
    status = 'warning';
  }
  
  return { status, issues };
}

// ==================== LINK ANALYZER ====================
let allLinks = [];
let currentFilter = 'all';

async function analyzeLinks() {
  const linkStats = document.getElementById('link-stats');
  const linksList = document.getElementById('links-list');
  
  linkStats.innerHTML = '<div class="loading">Analyzing links...</div>';
  linksList.innerHTML = '';
  
  try {
    // Get current page URL for internal/external detection
    const tab = await getCurrentTab();
    const currentUrl = new URL(tab.url);
    const currentDomain = currentUrl.hostname;
    
    // Analyze all links on the page
    const linkData = await executeScript(() => {
      const links = Array.from(document.querySelectorAll('a[href]'));
      const currentHostname = window.location.hostname;
      
      return links.map((link, index) => {
        const href = link.href;
        const anchorText = link.textContent.trim() || '(No anchor text)';
        const rel = link.getAttribute('rel') || '';
        const isNofollow = rel.includes('nofollow');
        
        // Determine if internal or external
        let isInternal = false;
        try {
          const linkUrl = new URL(href);
          isInternal = linkUrl.hostname === currentHostname;
        } catch (e) {
          // Relative URL, consider it internal
          isInternal = true;
        }
        
        return {
          href,
          anchorText,
          isNofollow,
          isInternal,
          index
        };
      });
    });
    
    allLinks = linkData;
    
    // Calculate statistics
    const totalLinks = allLinks.length;
    const internalLinks = allLinks.filter(l => l.isInternal).length;
    const externalLinks = allLinks.filter(l => !l.isInternal).length;
    const nofollowLinks = allLinks.filter(l => l.isNofollow).length;
    const telLinks = allLinks.filter(l => l.href.toLowerCase().startsWith('tel:')).length;
    const mailtoLinks = allLinks.filter(l => l.href.toLowerCase().startsWith('mailto:')).length;
    
    // Display stats
    linkStats.innerHTML = `
      <div class="stat-item">
        <div class="stat-number">${totalLinks}</div>
        <div class="stat-label">Total Links</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">${internalLinks}</div>
        <div class="stat-label">Internal</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">${externalLinks}</div>
        <div class="stat-label">External</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">${nofollowLinks}</div>
        <div class="stat-label">Nofollow</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">${telLinks}</div>
        <div class="stat-label">Tel</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">${mailtoLinks}</div>
        <div class="stat-label">Mailto</div>
      </div>
    `;
    
    // Setup filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        currentFilter = this.dataset.filter;
        renderLinks();
      });
    });
    
    // Render all links initially
    renderLinks();
    
  } catch (error) {
    linkStats.innerHTML = `<div class="empty-state"><p>Error: ${error.message}</p></div>`;
  }
}

function renderLinks() {
  const linksList = document.getElementById('links-list');
  
  // Filter links based on current filter
  let filteredLinks = allLinks;
  
  if (currentFilter === 'internal') {
    filteredLinks = allLinks.filter(l => l.isInternal);
  } else if (currentFilter === 'external') {
    filteredLinks = allLinks.filter(l => !l.isInternal);
  } else if (currentFilter === 'nofollow') {
    filteredLinks = allLinks.filter(l => l.isNofollow);
  }
  
  if (filteredLinks.length === 0) {
    linksList.innerHTML = '<div class="empty-state"><p>No links found for this filter</p></div>';
    return;
  }
  
  linksList.innerHTML = filteredLinks.map(link => {
    const typeClass = link.isInternal ? 'internal' : 'external';
    const brokenClass = link.isBroken ? ' broken' : '';
    const nofollowClass = link.isNofollow ? ' nofollow' : '';
    
    return `
      <div class="link-item ${typeClass}${brokenClass}${nofollowClass}">
        <div class="link-header">
          <div class="link-anchor">${link.anchorText}</div>
          <div class="link-badges">
            <span class="link-badge ${link.isInternal ? 'internal' : 'external'}">
              ${link.isInternal ? 'Internal' : 'External'}
            </span>
            <span class="link-badge ${link.isNofollow ? 'nofollow' : 'dofollow'}">
              ${link.isNofollow ? 'Nofollow' : 'Dofollow'}
            </span>
          </div>
        </div>
        <div class="link-url">${link.href}</div>
      </div>
    `;
  }).join('');
}

// Broken link detection removed due to browser security limitations:
// - CORS blocking prevents checking external sites
// - Social media sites block automated requests (bot detection)
// - No-CORS mode prevents reading actual HTTP status codes
// This caused too many false positives (working links marked as broken)

// ==================== TYPOGRAPHY ANALYZER ====================
async function analyzeTypography() {
  const fontFamilies = document.getElementById('font-families');
  const fontSizes = document.getElementById('font-sizes');
  
  fontFamilies.innerHTML = '<div class="loading">Analyzing...</div>';
  fontSizes.innerHTML = '<div class="loading">Analyzing...</div>';
  
  try {
    const typographyData = await executeScript(() => {
      const elements = document.querySelectorAll('*');
      const fonts = new Map();
      const sizes = new Map();
      
      elements.forEach(el => {
        const style = window.getComputedStyle(el);
        const fontFamily = style.fontFamily;
        const fontSize = style.fontSize;
        
        // Track font families
        if (fontFamily) {
          fonts.set(fontFamily, (fonts.get(fontFamily) || 0) + 1);
        }
        
        // Track font sizes
        if (fontSize) {
          sizes.set(fontSize, (sizes.get(fontSize) || 0) + 1);
        }
      });
      
      // Sort by usage count
      const sortedFonts = Array.from(fonts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 15);
      
      const sortedSizes = Array.from(sizes.entries())
        .sort((a, b) => {
          // Sort by pixel value
          const aVal = parseFloat(a[0]);
          const bVal = parseFloat(b[0]);
          return bVal - aVal;
        })
        .slice(0, 20);
      
      return {
        fonts: sortedFonts,
        sizes: sortedSizes
      };
    });
    
    // Render font families
    if (typographyData.fonts.length > 0) {
      fontFamilies.innerHTML = typographyData.fonts.map(([font, count]) => `
        <div class="font-item">
          <div>${font}</div>
          <div class="font-preview" style="font-family: ${font};">
            The quick brown fox jumps over the lazy dog
          </div>
          <div style="margin-top: 5px; font-size: 12px; color: #6c757d;">
            Used ${count} times
          </div>
        </div>
      `).join('');
    } else {
      fontFamilies.innerHTML = '<div class="empty-state"><p>No fonts found</p></div>';
    }
    
    // Render font sizes
    if (typographyData.sizes.length > 0) {
      fontSizes.innerHTML = '<div style="margin-bottom: 10px;">' + 
        typographyData.sizes.map(([size, count]) => `
          <span class="size-item">${size} (${count}×)</span>
        `).join('') +
        '</div>';
    } else {
      fontSizes.innerHTML = '<div class="empty-state"><p>No font sizes found</p></div>';
    }
    
  } catch (error) {
    fontFamilies.innerHTML = `<div class="empty-state"><p>Error: ${error.message}</p></div>`;
    fontSizes.innerHTML = '';
  }
}

// ==================== COLOR ANALYZER ====================
async function analyzeColors() {
  const mainColors = document.getElementById('main-colors');
  const bgColors = document.getElementById('bg-colors');
  const textColors = document.getElementById('text-colors');
  
  mainColors.innerHTML = '<div class="loading">Analyzing...</div>';
  bgColors.innerHTML = '<div class="loading">Analyzing...</div>';
  textColors.innerHTML = '<div class="loading">Analyzing...</div>';
  
  try {
    const colorData = await executeScript(() => {
      const elements = document.querySelectorAll('*');
      const bgColorMap = new Map();
      const textColorMap = new Map();
      const allColorMap = new Map();
      
      function rgbToHex(rgb) {
        const values = rgb.match(/\d+/g);
        if (!values || values.length < 3) return rgb;
        
        const r = parseInt(values[0]);
        const g = parseInt(values[1]);
        const b = parseInt(values[2]);
        
        return '#' + [r, g, b].map(x => {
          const hex = x.toString(16);
          return hex.length === 1 ? '0' + hex : hex;
        }).join('');
      }
      
      elements.forEach(el => {
        const style = window.getComputedStyle(el);
        
        // Background colors
        const bgColor = style.backgroundColor;
        if (bgColor && bgColor !== 'rgba(0, 0, 0, 0)' && bgColor !== 'transparent') {
          const hex = rgbToHex(bgColor);
          bgColorMap.set(hex, (bgColorMap.get(hex) || 0) + 1);
          allColorMap.set(hex, (allColorMap.get(hex) || 0) + 1);
        }
        
        // Text colors
        const textColor = style.color;
        if (textColor) {
          const hex = rgbToHex(textColor);
          textColorMap.set(hex, (textColorMap.get(hex) || 0) + 1);
          allColorMap.set(hex, (allColorMap.get(hex) || 0) + 1);
        }
      });
      
      const sortedBgColors = Array.from(bgColorMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10);
      
      const sortedTextColors = Array.from(textColorMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10);
      
      const sortedAllColors = Array.from(allColorMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 15);
      
      return {
        bgColors: sortedBgColors,
        textColors: sortedTextColors,
        allColors: sortedAllColors
      };
    });
    
    function renderColorSwatches(colors) {
      if (colors.length === 0) {
        return '<div class="empty-state"><p>No colors found</p></div>';
      }
      
      return colors.map(([color, count]) => `
        <div class="color-swatch" onclick="navigator.clipboard.writeText('${color}').then(() => alert('Copied ${color} to clipboard!'))">
          <div class="color-box" style="background-color: ${color};"></div>
          <div>
            <div class="color-code">${color}</div>
            <div class="color-count">${count} uses</div>
          </div>
        </div>
      `).join('');
    }
    
    mainColors.innerHTML = renderColorSwatches(colorData.allColors);
    bgColors.innerHTML = renderColorSwatches(colorData.bgColors);
    textColors.innerHTML = renderColorSwatches(colorData.textColors);
    
  } catch (error) {
    mainColors.innerHTML = `<div class="empty-state"><p>Error: ${error.message}</p></div>`;
    bgColors.innerHTML = '';
    textColors.innerHTML = '';
  }
}

// ==================== COLOR PICKER ====================
document.getElementById('color-picker-btn').addEventListener('click', async () => {
  try {
    // Check if EyeDropper API is available
    if (!window.EyeDropper) {
      alert('Color picker is not supported in your browser. Please use Chrome 95+ or Edge 95+');
      return;
    }
    
    const eyeDropper = new EyeDropper();
    const result = await eyeDropper.open();
    
    const pickedColorDisplay = document.getElementById('picked-color-display');
    pickedColorDisplay.innerHTML = `
      <div class="color-swatch" onclick="navigator.clipboard.writeText('${result.sRGBHex}').then(() => alert('Copied ${result.sRGBHex} to clipboard!'))">
        <div class="color-box" style="background-color: ${result.sRGBHex};"></div>
        <div>
          <div class="color-code">${result.sRGBHex}</div>
          <div class="color-count">Click to copy</div>
        </div>
      </div>
    `;
    
  } catch (error) {
    console.error('Color picker error:', error);
  }
});

