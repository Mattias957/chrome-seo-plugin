# Quick Installation Guide

## Install the Extension

1. **Open Chrome** and navigate to: `chrome://extensions/`

2. **Enable Developer Mode**
   - Look for the toggle switch in the top-right corner
   - Click to enable it

3. **Load the Extension**
   - Click the "Load unpacked" button
   - Navigate to and select this folder: `/Users/matthias/Documents/Chrome plugin`
   - Click "Select" or "Open"

4. **Pin the Extension** (Optional but Recommended)
   - Click the puzzle piece icon 🧩 in Chrome's toolbar
   - Find "Moreillon SEO"
   - Click the pin icon 📌 to keep it visible

## Start Using

1. Navigate to any website (e.g., https://example.com)
2. Click the Moreillon SEO icon in your toolbar
3. Choose a feature tab and click the analyze button!

## Quick Feature Guide

### 🖼️ Images
Click "Scan Images" → Select images → "Download Selected"

### 🔍 SEO
Click "Analyze SEO" → View comprehensive SEO data including:
- Quick links to sitemap.xml and robots.txt
- Visual heading structure (indented with varying sizes)
- Structured data/schema markup viewer (JSON-LD, Microdata, Open Graph, Twitter Cards)
- Complete meta information and heading summary

### 📝 Typography  
Click "Analyze Typography" → See all fonts and sizes used

### 🎨 Colors
Click "Analyze Colors" → View page colors  
Click "Pick Color from Page" → Use eyedropper to pick any color

## Troubleshooting

**Extension icon not showing?**
- Make sure you enabled Developer Mode
- Try reloading the extension (click the refresh icon)

**Not working on some pages?**
- Extensions can't run on `chrome://` pages for security reasons
- Try on a regular website like google.com or github.com

**Color picker not working?**
- Requires Chrome 95 or later
- Update Chrome if needed

## Tips

- Click any color swatch to copy the HEX code to clipboard
- The SEO analyzer warns you if there are multiple H1 tags (bad for SEO)
- All features work offline - no data is sent anywhere!

Enjoy analyzing websites! 🚀

