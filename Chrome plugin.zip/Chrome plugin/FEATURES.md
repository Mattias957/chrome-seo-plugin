# Feature Overview - Moreillon SEO

This document provides a detailed overview of all features in the extension.

---

## 🎯 Main Interface

The extension opens in a popup window (600px wide) with 4 main tabs:
- **Images** - Download images from any webpage
- **SEO** - Comprehensive SEO analysis
- **Typography** - Font and size analysis
- **Colors** - Color extraction and picker

---

## 📸 Tab 1: Images

### What It Does
Finds and displays all images on the current webpage in a visual grid.

### Features
- **Scan Images Button** - Analyzes the page for all `<img>` elements
- **Image Grid** - Responsive grid showing thumbnails (120px × 120px)
- **Image Info** - Shows dimensions (width × height) below each thumbnail
- **Selection** - Click any image to select/deselect (blue border + checkmark)
- **Bulk Actions**:
  - Select All
  - Deselect All
  - Download Selected (batch download)

### Smart Filtering
- Filters out broken images (naturalWidth = 0)
- Filters out invalid/missing src attributes
- Shows actual image dimensions

### Download Behavior
- Downloads to default Chrome downloads folder
- Filenames: `image_1_1729012345678.jpg`, `image_2_1729012345680.jpg`, etc.
- Uses timestamps to avoid conflicts
- No file dialogs (batch mode)

---

## 🔍 Tab 2: SEO ✨ NEW ENHANCED

### Quick Links Section

#### What It Shows
Direct clickable links to common SEO files:
- 📄 **View Sitemap.xml** - Opens `https://currentsite.com/sitemap.xml` in new tab
- 🤖 **View Robots.txt** - Opens `https://currentsite.com/robots.txt` in new tab

#### Why It's Useful
No need to manually type URLs - instant access to critical SEO files.

---

### Meta Information Section

Shows all important meta tags:
- **Title** (short preview + full title)
- **Meta Description**
- **Meta Keywords**
- **Canonical URL** (link rel="canonical")
- **OG Title** (Open Graph for social media)
- **OG Description**

---

### Heading Structure Section ⭐ GAME CHANGER

#### Visual Representation
Shows ALL headings from the page in document order with:

**Indentation by Level:**
- H1: No indentation (0px)
- H2: 20px indent
- H3: 40px indent
- H4: 60px indent
- H5: 80px indent
- H6: 100px indent

**Font Size by Level:**
- H1: 18px (largest, bold)
- H2: 16px (bold)
- H3: 15px (semi-bold)
- H4: 14px
- H5: 13px
- H6: 12px (smallest)

**Color-Coded Tags:**
Each heading has a colored badge showing its level:
- H1: 🔴 Red (indicates importance + warning if multiple)
- H2: 🟣 Purple
- H3: 🟪 Dark Purple
- H4: 🟢 Green
- H5: 🟡 Yellow
- H6: ⚫ Gray

#### Example Display

```
[H1] Welcome to Our Site                    (18px, no indent, red)
  [H2] About Us                             (16px, 20px indent, purple)
    [H3] Our Mission                        (15px, 40px indent, dark purple)
    [H3] Our Vision                         (15px, 40px indent, dark purple)
  [H2] Services                             (16px, 20px indent, purple)
    [H3] Web Design                         (15px, 40px indent, dark purple)
      [H4] Responsive Design                (14px, 60px indent, green)
      [H4] Mobile First                     (14px, 60px indent, green)
```

#### Over-Optimization Detection
Instantly spot problems:
- ❌ Multiple H1 tags (bad for SEO)
- ❌ Skipping heading levels (H1 → H3 without H2)
- ❌ Too many headings of same level
- ❌ Unnatural heading patterns
- ✅ Clean, logical hierarchy

---

### Heading Summary Section

Traditional count-based view:
- Total number of headings
- Count for each level (H1-H6)
- Shows first 3 examples of each heading type
- ⚠️ Red badge if multiple H1s detected

---

### Structured Data / Schema Markup Section ⭐ NEW

#### What It Detects

**1. JSON-LD** (Most Common)
- Finds all `<script type="application/ld+json">` tags
- Displays schema type (Article, Product, Organization, etc.)
- Click to expand and view formatted JSON
- Shows complete structured data

Example types found:
- Article
- Product
- Organization
- Person
- BreadcrumbList
- FAQPage
- HowTo
- Recipe
- Event
- etc.

**2. Microdata**
- Detects elements with `itemscope` attribute
- Shows count of microdata items
- Lists item types found

**3. Open Graph**
- All `<meta property="og:*">` tags
- Formatted as JSON for easy reading
- Click to expand

**4. Twitter Cards**
- All `<meta name="twitter:*">` tags
- Formatted as JSON
- Click to expand

#### Why This Matters
- See what Google/Bing see for rich snippets
- Verify social media sharing data
- Debug schema implementation
- No need for external testing tools
- All in one place

#### Display Format
```
Found: 3 schema type(s)

[JSON-LD - Article] [Click to view]
  └─ (Click to expand JSON)

[Open Graph] [Click to view]
  └─ (Click to expand data)

[Twitter Cards] [Click to view]
  └─ (Click to expand data)
```

---

## 📝 Tab 3: Typography

### Font Families Section
- Lists all font families used on the page
- Sorted by usage count (most used first)
- Live preview of each font (sample text)
- Shows usage count

### Font Sizes Section
- All font sizes used (sorted largest to smallest)
- Displayed as colored badges
- Shows how many times each size appears
- Format: "16px (235×)" means 16px used 235 times

---

## 🎨 Tab 4: Colors

### Color Picker Tool
- **🎨 Pick Color from Page** button
- Opens eyedropper cursor
- Click anywhere on webpage to pick color
- Shows picked color with HEX code
- Click color swatch to copy HEX to clipboard

### Main Colors Section
- Top 15 most used colors across the page
- Includes both background and text colors
- Sorted by frequency

### Background Colors Section
- Top 10 background colors
- Sorted by frequency
- Excludes transparent/rgba(0,0,0,0)

### Text Colors Section
- Top 10 text colors
- Sorted by frequency

### Color Display Format
Each color shown as:
```
[Color Swatch] #667eea
               342 uses
```
- 40px × 40px color box
- HEX code
- Usage count
- Click to copy HEX code

---

## 🎨 Design Features

### Visual Design
- Purple gradient theme (#667eea → #764ba2)
- Smooth animations and transitions
- Hover effects on all interactive elements
- Professional shadows and depth
- Responsive layouts

### UI/UX Features
- Tab-based navigation
- Sticky tab bar when scrolling
- Loading states for all actions
- Empty states with helpful messages
- Scrollable sections for large data
- Custom styled scrollbars
- Click-to-copy functionality
- Expandable sections

### Accessibility
- Clear visual hierarchy
- High contrast colors
- Readable font sizes
- Descriptive labels
- Hover states
- Click feedback

---

## 🔒 Privacy & Security

### What It Does
- ✅ Runs locally in your browser
- ✅ No data sent to external servers
- ✅ No tracking or analytics
- ✅ No accounts or login required
- ✅ Only analyzes when you click buttons

### What It Doesn't Do
- ❌ No background scanning
- ❌ No data collection
- ❌ No remote connections
- ❌ No ads or monetization
- ❌ No third-party libraries

### Permissions Used
- `activeTab` - Access current tab content (only when popup is open)
- `downloads` - Download selected images
- `scripting` - Execute analysis scripts on the page

---

## 💡 Pro Tips

### For Developers
- Use heading structure view to verify HTML hierarchy
- Check schema markup before deployment
- Verify meta tags for social sharing
- Download design assets with image tool
- Extract color palette for branding

### For SEO Professionals
- Quick access to sitemap for audits
- Verify structured data implementation
- Check heading optimization
- Monitor meta tag compliance
- Validate canonical URLs

### For Designers
- Extract color schemes from competitors
- Analyze typography choices
- Download image assets
- Use color picker for exact matches
- Study font combinations

### For Content Writers
- Verify heading structure matches outline
- Check meta description length
- Ensure proper H1 usage
- Review heading hierarchy
- Validate title tags

---

## 🚀 Performance

- Instant analysis (< 1 second for most pages)
- No page refresh required
- Lightweight (< 100KB total size)
- No external dependencies
- Runs in isolated popup (doesn't slow down page)

---

## 🔄 Browser Compatibility

### Fully Supported ✅
- Google Chrome 95+
- Microsoft Edge 95+
- Brave Browser (Chromium)
- Opera (Chromium)
- Any Chromium-based browser

### Not Supported ❌
- Firefox (different extension API)
- Safari (different extension API)

### Feature Requirements
- **Color Picker**: Requires Chrome 95+ (EyeDropper API)
- **All Other Features**: Work on Chrome 88+

---

## 📊 Comparison with Competitors

### vs. Built-in Dev Tools
✅ Easier to use - no technical knowledge needed
✅ Visual representation of data
✅ One-click downloads
✅ Better heading visualization
✅ Schema viewer more readable

### vs. Online SEO Tools
✅ No need to leave the page
✅ Instant results
✅ Works offline
✅ Private - no data sent
✅ Free - no limits

### vs. Other Extensions
✅ All-in-one solution
✅ Modern UI
✅ More comprehensive schema detection
✅ Better heading structure view
✅ Color picker included

---

**Version:** 1.0.0
**Last Updated:** October 2025

