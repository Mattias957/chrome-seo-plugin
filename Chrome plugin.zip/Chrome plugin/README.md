# Matthias SEO plugin - Chrome Extension

A professional Chrome extension for web developers, SEO specialists, and designers that provides comprehensive analysis tools for any webpage.

**🎨 DETAILED-Inspired Design** - Professional UI with status badges, character counts, and enhanced visual indicators!

## Features

### 🖼️ Image Downloader
- Scan and display all images on any webpage
- Preview images in a grid layout with thumbnails
- Select individual or all images
- Batch download selected images
- View image dimensions

### 🔍 SEO Analyzer
- **Quick Links** - Direct access to sitemap.xml and robots.txt
- **Structured Data Viewer** - See all schema markup (JSON-LD, Microdata, Open Graph, Twitter Cards)
- **Visual Heading Structure** - See ALL headings with indentation showing hierarchy
- **Varying Font Sizes** - Headings display at different sizes (H1 largest, H6 smallest)
- **Color-Coded Tags** - Different colors for each heading level
- Count all heading tags (H1-H6) with summary
- View heading structure and examples
- Check meta title, description, and canonical URL
- Analyze Open Graph tags and Twitter Cards
- View meta keywords
- Get SEO recommendations (e.g., multiple H1 tags warning)

### 📝 Typography Analyzer
- Discover all fonts used on the page
- See live font previews
- View all font sizes used
- Sort by usage frequency
- Understand the typography hierarchy

### 🎨 Color Analyzer & Picker
- Extract main colors from the page
- Analyze background colors
- Analyze text colors
- See color usage statistics
- **Color Picker Tool** - Pick any color from the webpage using an eyedropper
- Click any color to copy HEX code to clipboard

## Installation

### Method 1: Load as Unpacked Extension (Recommended for Development)

1. Open Google Chrome
2. Navigate to `chrome://extensions/`
3. Enable "Developer mode" (toggle in the top-right corner)
4. Click "Load unpacked"
5. Select the folder containing this extension (`Chrome plugin` folder)
6. The extension icon should appear in your toolbar

### Method 2: Pin the Extension

After installation:
1. Click the puzzle piece icon in Chrome's toolbar
2. Find "Web Analyzer Pro"
3. Click the pin icon to keep it visible

## Usage

1. **Navigate to any webpage** you want to analyze
2. **Click the extension icon** in your toolbar
3. **Choose a tab** based on what you want to analyze:

### Images Tab
- Click "Scan Images" to find all images
- Click on thumbnails to select/deselect
- Use "Select All" or "Deselect All" buttons
- Click "Download Selected" to download chosen images

### SEO Tab
- Click "Analyze SEO" to view comprehensive SEO metrics
- **Quick Links**: Click to open sitemap.xml or robots.txt in new tab
- **Heading Structure**: See all headings indented by level with varying sizes
  - H1 headings are largest and left-aligned (red)
  - H2-H6 progressively smaller and indented more
  - Easy to spot over-optimization or unnatural structure
- **Heading Summary**: Count and examples of each heading type
- **Structured Data**: View all schema markup
  - JSON-LD schemas (click to expand)
  - Microdata
  - Open Graph tags
  - Twitter Cards
- Check meta title, description, canonical URL
- Look for SEO issues (highlighted in red)

### Typography Tab
- Click "Analyze Typography" to scan fonts
- View all font families with live previews
- See all font sizes sorted by size
- Check usage statistics

### Colors Tab
- Click "Analyze Colors" to extract page colors
- View main, background, and text colors
- Click any color swatch to copy HEX code
- Click "Pick Color from Page" to use the eyedropper tool
- Click anywhere on the webpage to pick that color

## Technical Details

- **Manifest Version:** 3
- **Permissions:** 
  - `activeTab` - Access current tab content
  - `downloads` - Download images
  - `scripting` - Execute analysis scripts
- **Supported Browsers:** Chrome 95+, Edge 95+

## Browser Compatibility

- ✅ Google Chrome 95+
- ✅ Microsoft Edge 95+
- ✅ Brave (Chromium-based)
- ✅ Opera (Chromium-based)
- ❌ Firefox (uses different extension API)
- ❌ Safari (uses different extension API)

## Features in Detail

### Color Picker
The color picker uses the modern EyeDropper API available in Chrome 95+. This allows you to:
- Pick colors from anywhere on the webpage
- Get precise HEX color codes
- Copy colors to clipboard with one click

### Image Downloader
- Filters out tiny images (icons, etc.)
- Shows actual image dimensions
- Downloads with sequential naming
- No file size limits

### SEO Analyzer - NEW ENHANCED FEATURES ✨

#### Quick Links
- One-click access to sitemap.xml
- One-click access to robots.txt
- Opens in new tab for easy access

#### Structured Data / Schema Markup Viewer
View all structured data without leaving the page or using external tools:
- **JSON-LD** - Click to expand and view formatted JSON
- **Microdata** - Shows count and types found
- **Open Graph** - All og: meta tags in one place
- **Twitter Cards** - All twitter: meta tags
- See exactly what search engines and social platforms see

#### Visual Heading Structure
This is a game-changer for SEO analysis:
- **Indentation** - Each heading level is indented (H1 at 0px, H2 at 20px, H3 at 40px, etc.)
- **Font Sizes** - Headings rendered at different sizes (H1 at 18px down to H6 at 12px)
- **Color-Coded** - Each level has a unique color:
  - H1: Red (most important, should only have ONE)
  - H2: Purple
  - H3: Dark Purple
  - H4: Green
  - H5: Yellow
  - H6: Gray
- **Document Order** - Shows ALL headings in the exact order they appear
- **Over-optimization Detection** - Instantly spot unnatural heading patterns
- **Hierarchy Visualization** - See if your heading structure makes logical sense

#### Traditional SEO Checks
- Warns if multiple H1 tags found (SEO best practice)
- Shows first few examples of each heading type
- Displays complete meta information
- Checks for Open Graph compliance
- Shows canonical URL
- Displays meta description and keywords

## Troubleshooting

**Extension not working on some pages:**
- Some pages (chrome://, chrome.google.com) block extensions for security
- Try on a regular website

**Color picker not working:**
- Ensure you're using Chrome 95 or later
- Update your browser if needed

**Images not downloading:**
- Check your download settings in Chrome
- Ensure downloads aren't blocked
- Some images may be restricted by CORS policy

## Privacy

This extension:
- ✅ Works entirely locally - no data sent to servers
- ✅ Only analyzes pages when you click analyze buttons
- ✅ Does not track or collect any user data
- ✅ Does not require account or login
- ✅ Open source - you can review all code

## Development

Built with:
- Vanilla JavaScript (no frameworks)
- Chrome Extension Manifest V3
- Modern CSS with gradients and animations
- EyeDropper API for color picking

## Support

For issues or feature requests, please review the code or modify as needed.

## License

Free to use and modify.

---

**Version:** 1.0.0
**Last Updated:** October 2025

