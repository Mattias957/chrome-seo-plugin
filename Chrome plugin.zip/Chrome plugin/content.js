// Content script - runs in the context of web pages
// This script helps with communication between the page and the extension

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'ping') {
    sendResponse({ status: 'ready' });
  }
  return true;
});

// Log that the content script is loaded
console.log('Moreillon SEO content script loaded');

